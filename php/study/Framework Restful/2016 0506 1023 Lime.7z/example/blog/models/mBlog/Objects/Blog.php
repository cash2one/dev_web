<?php

namespace mBlog\Objects;

class Blog extends \C\Model
{
    protected $db;

    public function __construct()
    {
        $this->db = services('database');
    }

    public function addNew($title, $content)
    {
        $sql = "INSERT INTO {{posts}} (title,content,uid,date_add) VALUES (:title,:content,:uid,NOW())";

        $sth = $this->db->query($sql, [
            ':title' => $title,
            ':content' => $content,
            ':uid' => $_SESSION['uid'],
        ]);

        if ($sth->rowCount()) {
            return $this->db->lastInsertId();
        } else {
            return false;
        }
    }

    public function get($pid)
    {
        $sql = "SELECT * FROM {{posts}} p LEFT JOIN {{users}} u ON (p.uid=u.uid) WHERE pid=:pid";

        $sth = $this->db->query($sql, [
            ':pid' => $pid,
        ]);

        if ($row = $sth->fetch()) {
            return $row;
        } else {
            return false;
        }
    }

    public function update($pid, $title, $content)
    {
        $sql = "UPDATE {{posts}} SET 
                title=:title,
                content=:content
                WHERE pid=:pid";

        $sth = $this->db->query($sql, [
            ':title' => $title,
            ':content' => $content,
            ':pid' => $pid,
        ]);
    }

    public function getAll() {
    
    	$sql = "SELECT * FROM {{posts}} ORDER BY date_add DESC";
    
    	$sth = $this->db->query($sql);
    
    	while($row = $sth->fetch()) {
    		$this->add($row);
    	}
    	return $this;
    }
    
    public function getDateAdd($date)
    {
    	$date = strtotime($date);
    	$etime = time() - $date;
    	if ($etime < 1) {
    		return '刚刚';
    	}
    
    	$interval = array(
    			12 * 30 * 24 * 60 * 60 => '年前 (' . date('Y-m-d', $date) . ')',
    			30 * 24 * 60 * 60 => '个月前 (' . date('m-d', $date) . ')',
    			7 * 24 * 60 * 60 => '周前 (' . date('m-d', $date) . ')',
    			24 * 60 * 60 => '天前',
    			60 * 60 => '小时前',
    			60 => '分钟前',
    			1 => '秒前',
    	);
    	foreach ($interval as $secs => $str) {
    		$d = $etime / $secs;
    		if ($d >= 1) {
    			$r = round($d);
    			return $r . $str;
    		}
    	};
    }
    
    public function getEditLink()
    {
    	$pid = $this->row('pid');
    
    	return url_for('post-edit', ['pid' => $pid]);
    }
}