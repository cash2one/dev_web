<?php

namespace mApp\Controller;

class Front
{
    public function __construct()
    {
        # code...
    }
}