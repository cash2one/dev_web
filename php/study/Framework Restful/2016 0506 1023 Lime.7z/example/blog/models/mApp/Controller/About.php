<?php

namespace mApp\Controller;

class About extends Front
{
    public function index()
    {
        return view('about.php');
    }
}