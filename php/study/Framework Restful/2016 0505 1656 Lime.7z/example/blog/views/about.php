<?php $this->extend('layout.php'); ?>

<article>
    <h1 class="entry-title">关于</h1>
    <p>这是一个关于我的页面。个人博客通常有类似这样的介绍：</p>
    <blockquote><p>欢迎！我白天是个邮递员，晚上就是个有抱负的演员。这是我的博客。我住在天朝的帝都，有条叫做杰克的狗。</p></blockquote>
</article>

<?php $this->section('title', '关于我testabout'); ?>