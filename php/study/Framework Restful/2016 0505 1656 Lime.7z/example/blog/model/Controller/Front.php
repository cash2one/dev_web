<?php

namespace Controller;

class Front
{
    public function __construct()
    {
        # code...
    }
}