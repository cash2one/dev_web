<?php

namespace C\E;

class NotFoundException extends \Exception
{
}