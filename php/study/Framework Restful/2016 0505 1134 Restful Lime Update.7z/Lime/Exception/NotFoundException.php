<?php

namespace Lime\Exception;

class NotFoundException extends \Exception
{
}