<?php $this->extend('layout.php') ?>

<section class="not-found">
    <div>
        <p>抱歉！您要找的页面不存在！</p>
    </div><!-- .page-content -->
</section><!-- .error-404 -->